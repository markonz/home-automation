export const firebaseConfig = {
  "apiKey": "AIzaSyA_j8EF3xuKAgAIzaSyBoh8z5X0jY5LXrsf8MDDCvt9NIMShk7i0ZF1N4yuoF9EUb3k64ZvU",
    "authDomain": "home-automation-2ded4.firebaseapp.com",
    "databaseURL": "https://home-automation-2ded4.firebaseio.com",
    "projectId": "home-automation-2ded4",
    "storageBucket": "home-automation-2ded4.appspot.com",
    "messagingSenderId": "522966262992"
}

export default firebaseConfig;
