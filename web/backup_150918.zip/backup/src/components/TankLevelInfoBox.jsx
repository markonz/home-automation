import React, { Component } from 'react';
import PropTypes from 'prop-types';

import './TankLevelInfoBox.css';

//var measTypes = require('./measurementDefs.json');

class TankLevelInfoBox extends Component {
  constructor(props) {
    super(props);
  }

  handleClick() {
      alert("clieked");
  }

  formatDataAge(updateTimestamp) {
    const now = new Date();
    let dataAge = now - updateTimestamp;
    let format = "";

    let minutes = Math.floor(dataAge / (1000 * 60));
    let hours = Math.floor(minutes / 60);

    minutes -= (hours*60);

    if(hours > 17) {
      format = hours + ' h';
    } else if(hours > 0) {
      format = hours + ' h ' + minutes + ' min';
    }  else {
      format = minutes + ' min';
    }

    return(format);
  }

  render() {
    return (
      <div
        className="TankLevelInfoBox"
        onClick={this.handleClick}
      >
        <div
          className="StatusHeader"
          >
          {this.props.sensorType}
        </div>
        
        <div
          className="StatusValue centerVertical"
          >
          {this.props.latestValue}
        </div>

        <div
          className="StatusFooter"
          >
        <div className="left">{this.props.sensorBattery}</div>
        <div className="right">{this.formatDataAge(this.props.dataAge)}</div>
        </div>
      </div>
    );
  }
}

export default TankLevelInfoBox;
