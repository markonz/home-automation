import React, { Component } from 'react';
import PropTypes from 'prop-types';

import * as firebase from 'firebase';

import StatusInfoBox from './components/StatusInfoBox';

class TankLevelReading extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  componentWillMount() {

    firebase.firestore().collection('tankLevelReadings')
      .orderBy('measTime', 'desc')
      .limit(1)
      .onSnapshot( (snapshot) => {
        const latestUpdate = snapshot.docs[0].data();

        console.log("slapshot", snapshot.docs[0]);
        const data = {
          latestValue: latestUpdate.distance,
          sensorBattery: latestUpdate.sensorBattery.toString() + " mV",
          measTime: latestUpdate.measTime.toDate(),
          sensorType: "STRG"
        };
        this.setState({
          infoboxData: data
          });
      });
  }

  render() {
    return (
      this.state.infoboxData ? <StatusInfoBox data={this.state.infoboxData} /> : null
    );
  }
}

export default TankLevelReading;
