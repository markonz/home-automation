import React, { Component } from 'react';
import './App.css';

import SensorReading from './SensorReading';
import TankLevelReading from './TankLevelReading';

import Graph from './Graph';

import * as firebase from 'firebase';
import firebaseConfig from './config'

firebase.initializeApp(firebaseConfig);
firebase.firestore().settings({ timestampsInSnapshots: true });

class App extends Component {   

    constructor() {
        super();
        this.state = {
            title: "home-automation",
            graphData: []
        };
    }
    
   componentDidMount() {
        let startDate = new Date();
        startDate.setDate(startDate.getDate() - 3);

        console.log("startDate", startDate);
        firebase.firestore().collection('measurements')
            .where('measType', '==', 1)
            .where('measTime', '>', startDate)
            .orderBy('measTime', 'desc')
            .get()
            .then(snapshot => {
                var plotData = [];
                var gdata = [];
                
                snapshot.forEach(doc => {
                    const data = doc.data();
                    let strTimestamp = data.measTime.toDate().getTime();
                    var point = {
                        x: strTimestamp,
                        y: data.value
                    };
                    
//                    console.log("graphdata", point.x);
                    gdata.push(point);
                });

                plotData.push(gdata);
                
//                console.log(gdata);
//                console.log(snapshot);
                this.setState({
                    graphData: plotData
                });

        });
    }
  
    //        <Graph data={this.state.graphData}/>
//<StatusInfoBox sensorType="1"/>
render() {      
    return (
      <div className="App">
        <header className="App-header">
        </header>
        <SensorReading sensorType="1" sensorLocation="0" sensorTitle="TEMP 0" />
        <SensorReading sensorType="1" sensorLocation="1" sensorTitle="TEMP 1" />
        <SensorReading sensorType="1" sensorLocation="2" sensorTitle="TEMP 2" />
      </div>
    );
  }
}
/*
        <TankLevelReading />
        { this.state.graphData.length > 0 ? <Graph data={this.state.graphData}/> : null }
*/

export default App;
